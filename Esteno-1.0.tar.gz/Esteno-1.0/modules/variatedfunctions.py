
def pLDDT_dict(uniprotid):
    dict={}
    fd=open(uniprotid+".pdb","r")
    for line in fd:
        line2=line.split()
        if line2[0]=="ATOM" and line2[2]=="CA":
            dict[int(line2[5])]=float(line2[10])

    return dict

def matrix_iterator(dict, class_name, lenseq):
    i=0
    j=0
    while i<lenseq:
        vector=[]
        while j<lenseq:
            vector.append(PAE_dict["distance"][j+i*lenseq])
            j+=1
        yield class_name(i+1, vector, pLDDT_dict[i+1])
        j=0
        i+=1
