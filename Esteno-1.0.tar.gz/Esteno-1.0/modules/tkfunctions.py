from tkinter import *
from PIL import ImageTk, Image
import os
from tkinter import messagebox
from modules.main_esteno import main
#from tkinter.ttk import Progressbar
#import time


def createmiFrame():
    global miFrame
    miFrame=Frame()
    miFrame.pack(fill="both", expand="True")
    # instead of both you can put x or y... and many things here (video 43)
    miFrame.config(bg="white")
    #miFrame.config(width="900", height="550")
    miFrame.config(bd=40)
    miFrame.config(relief="sunken")

def createmiFrame4():
    """Results frame"""

    miFrame.destroy()

    createmiFrame()

    title=Label(miFrame, text="Esteno (Flexibility assesment without protein convolutional network)", font=("",20))
    title.grid(row=0,column=1, padx=10, pady=10)

    title=Label(miFrame, text="Instructions:", bg="red", font=("",18))
    title.grid(row=2,column=1, padx=10, pady=10)


    text1=Label(miFrame, text="ESTENO v.1.0", bg="white", font=("",15))
    text1.grid(row=3,column=1, padx=10, pady=10)

    text2=Label(miFrame, text="Esteno is a non-machine learning approach to assess the flexibility all the residues residues in a protein.", bg="white", font=("",11))
    text2.grid(row=4,column=1, padx=10, pady=10)

    text3=Label(miFrame, text="0. Install Esteno:", font=("",13))
    text3.grid(row=5,column=1, padx=10, pady=10)

    text4=Label(miFrame, text="The source code can be downloaded from #github link#. Installation is executed with thw following command: pip3 install Esteno-1.0.tar.gz", bg="white", font=("",11))
    text4.grid(row=6,column=1, padx=10, pady=10)

    text5=Label(miFrame, text="1. Command line version", font=("",13))
    text5.grid(row=7,column=1, padx=10, pady=10)

    text6=Label(miFrame, text="This can be run in the command line using: Esteno <fasta>", bg="white", font=("",11))
    text6.grid(row=8,column=1, padx=10, pady=10)

    text7=Label(miFrame, text="2. Graphical interface version", font=("",13))
    text7.grid(row=9,column=1, padx=10, pady=10)

    text8=Label(miFrame, text="The graphical interface is displayed using the command: RunEsteno", bg="white", font=("",11))
    text8.grid(row=10,column=1, padx=10, pady=10)

    text14=Label(miFrame, text="3. Output files",font=("",13))
    text14.grid(row=11,column=1, padx=10, pady=10)

    text15=Label(miFrame, text="The programme gives two main outputs:", bg="white", font=("",11))
    text15.grid(row=12,column=1, padx=10, pady=10)

    text16=Label(miFrame, text="* Scores table: .csv file containing the numerical score (in a range 0-2) for each residue in the given protein.", bg="white", font=("",11))
    text16.grid(row=13,column=1, padx=10, pady=10)

    text17=Label(miFrame, text="* Scores sequence: .txt file containing the sequence and the numerical score as a string.", bg="white", font=("",11))
    text17.grid(row=14,column=1, padx=10, pady=10)

    text18=Label(miFrame, text="* Scores visualisation: Image in .png format.", bg="white", font=("",11))
    text18.grid(row=15,column=1, padx=10, pady=10)

    text19=Label(miFrame, text="Other files are also produced during the process:",bg="white",font=("",11))
    text19.grid(row=16,column=1, padx=10, pady=10)

    text20=Label(miFrame, text="* The PAE matrix is saved with the swissprot protein ID name in xml format.", bg="white",font=("",11))
    text20.grid(row=17,column=1, padx=10, pady=10)

    text21=Label(miFrame, text="All files mentioned above are automatically saved in the working directory.", bg="white",font=("",11))
    text21.grid(row=18,column=1, padx=10, pady=10)


def createmiFrame3():
    """Results frame"""

    miFrame.destroy()

    createmiFrame()


    title=Label(miFrame, text="Esteno (Flexibility assesment without protein convolutional network)",font=("",20))
    title.grid(row=0,column=1, padx=10, pady=10)

    title=Label(miFrame, text="Results:",font=("",15))
    title.grid(row=2,column=1, padx=10, pady=10)

    global miImagen2
    miImagen2=PhotoImage(file="flex_score_by_residue.png")

    results=Label(miFrame, image=miImagen2)
    results.grid(row=3,column=1, padx=10, pady=10)


def createmiFrame2():
    """Waiting screen"""

    miFrame.destroy()

    createmiFrame()

    title=Label(miFrame, text="Esteno (Flexibility assesment without protein convolutional network)",font=("",20))
    title.grid(row=0,column=1, padx=10, pady=10)

    title=Label(miFrame, text="Please wait, programme running...",font=("",15))
    title.grid(row=2,column=1, padx=10, pady=10)


def createmiFrame1():
    """Main Frame, starting one"""
    try:
        miFrame.destroy()
    except:
        print("")

    createmiFrame()

    title=Label(miFrame, text="Esteno (Flexibility assesment without protein convolutional network)",font=("",20))
    title.grid(row=0,column=1, padx=10, pady=10)

    sequenceLabel=Label(miFrame, text="Sequence:",font=("",15))
    sequenceLabel.grid(row=2,column=1, padx=10, pady=10)

    sequence=StringVar()

    cuadroTexto = Text(miFrame, width=60, height=12,font=("",14))
    cuadroTexto.grid(column=1, row=3, padx=10, pady=10)

    scrollVert=Scrollbar(miFrame, command=cuadroTexto.yview)
    scrollVert.grid(row=3, column=2, sticky="nsew")

    cuadroTexto.config(yscrollcommand=scrollVert.set)

    # def start(sequence):
    #     tasks=20
    #     x=0
    #     while(x<tasks):
    #         time.sleep(1)
    #         bar["value"]+=5
    #         x+=1
    #         if x==10:
    #             os.system('python3 mainscript.py ' +sequence)
    #         miFrame.update_idletasks()



    def button_code():
        sequence=cuadroTexto.get("1.0","end")
        print("Running...")
        createmiFrame2()
        messagebox.showinfo("Protein flexibillity", "The programme will start to run, please pulse OK and wait.")   #si no posara algo ací es buggeja i no va no sé pq
        #os.system('python3 Esteno1.0-cmd.py ' +sequence)
        #sequence=sequence.strip()
        main(sequence.strip())
        #start(sequence)
        messagebox.showinfo("Protein flexibillity", "The job was executed successfully!")
        createmiFrame3()


    buttonSend=Button(miFrame, text="Send", command=button_code)
    buttonSend.grid(row=4,column=1, padx=10, pady=10)

    # bar = Progressbar(miFrame,orient=HORIZONTAL,length=300)
    # bar.grid(row=5, column=1, pady=10)
