class Element():

    aa_flex={"A":  0.360, "R":  0.530, "N":  0.460, "D":  0.510, "C":  0.350,
    "Q":  0.490, "E":  0.500, "G":  0.540, "H":  0.320, "I":  0.460,
    "L":  0.370, "K":  0.470, "M":  0.300, "F":  0.310, "P":  0.510,
    "S":  0.510, "T":  0.440, "W":  0.310, "Y":  0.420, "V":  0.390}

    aa_flexNS={"A":  0, "R":  1, "N":  0, "D":  1, "C":  0,
    "Q":  0, "E":  1, "G":  1, "H":  0, "I":  0,
    "L":  0, "K":  0, "M":  0, "F":  0, "P":  1,
    "S":  1, "T":  0, "W":  0, "Y":  0, "V":  0}

    def __init__(self, position, vector):
        self.position = position
        self.vector = vector

    def get_position(self):
        return self.position

    def get_vector(self):
        return self.vector


    def get_aa(self, sequence):
        return sequence[self.get_position()-1]

    def get_aa_flex(self, sequence):
        return self.aa_flex[self.get_aa(sequence)]

    def get_aa_flexNS(self, sequence):
        return self.aa_flexNS[self.get_aa(sequence)]

    def vector_mean(self):
        vector=self.get_vector()
        mean=sum(vector)/len(vector)
        return mean

    def diag_score(self, lenseq):
        position=self.get_position()
        max=lenseq-2
        if 2<position and position<max:
            mynums=self.get_vector()[position-3:position+2]
            score=sum(mynums)/len(mynums)
        else:
            score=2
        return score

    def score_squares0(self, lenseq):
        position=self.get_position()
        max=lenseq-2
        if 2<position and position<max:
            mynums=self.get_vector()[position-3:position+2]
        else:
            mynums=[]
        return mynums

    def score_squares1(self, lenseq):
        position=self.get_position()
        max=lenseq-1
        if 3<position and position<max:
            mynums=self.get_vector()[position-4:position+1]
        else:
            mynums=[]
        return mynums

    def score_squares2(self, lenseq):
        position=self.get_position()
        max=lenseq
        if 4<position and position<max:
            mynums=self.get_vector()[position-5:position]
        else:
            mynums=[]
        return mynums

    def score_squares3(self, lenseq):
        position=self.get_position()
        max=lenseq-3
        if 1<position and position<max:
            mynums=self.get_vector()[position-2:position+3]
        else:
            mynums=[]
        return mynums

    def score_squares4(self, lenseq):
        position=self.get_position()
        max=lenseq-4
        if 0<position and position<max:
            mynums=self.get_vector()[position-1:position+4]
        else:
            mynums=[]
        return mynums

    # def score_xavi2(self, max):
    #     # max=lenseq here so when call that function pass lenseq. ex: final_scores.append(element.score_xavi2(lenseq))
    #     position=self.get_position()
    #     if 0<position and position<max:
    #         score=self.get_vector()[position]-self.get_vector()[position-1]
    #     else:
    #         score=1
    #     return score
