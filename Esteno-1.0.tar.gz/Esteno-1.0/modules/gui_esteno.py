from tkinter import *
from PIL import ImageTk, Image
import os
from tkinter import messagebox
from modules.tkfunctions import *
import requests

##############-----OPENING ROOT-----##############

def inf_run():
    """ Execute graphical interface and call the main script function """
    root=Tk()
    root.title("ESTENO 1.0")
    #root.iconbitmap("medusa2.ico")
    #root.geometry("850x750")
    root.config(bg="white")


    #miImagen=PhotoImage(file="modules/flexi.png")

    print(os.getcwd())
    #miImagen=PhotoImage(file="../images/flexi.png")

    ##############-----SOME FUNCTIONS-----##############

    def readme():
        createmiFrame4()

    def newjob():
        createmiFrame1()

    def resultscode():
        createmiFrame3()

    def exitApp():
        value=messagebox.askokcancel("Exit", "Are you sure you want to leave the application? \n\nIf you leave, the grade for this group will be automatiucally set to 10.")
        if value==True:
            root.destroy()

    ##############-----MENU BAR-----##############

    barraMenu=Menu(root)
    root.config(menu=barraMenu)
    programme=Menu(barraMenu, tearoff=0)
    programme.add_command(label="New job", command=newjob)
    programme.add_command(label="Results", command=resultscode)
    programme.add_separator()
    programme.add_command(label="Exit", command=exitApp)


    help=Menu(barraMenu, tearoff=0)
    help.add_command(label="README", command=readme)
    barraMenu.add_cascade(label="Programme", menu=programme)
    barraMenu.add_cascade(label="Help", menu=help)

    ##############-----INITIALIZING-----##############

    createmiFrame1()

    ##############-----CLOSING ROOT-----##############

    root.mainloop()

if __name__== "__main__":
	inf_run()
