import pandas as pd

def classify_3_clases(lista, lenseq, downcut, upcut):
    i=0
    resultados=[]
    while i<lenseq:
        if lista[i] < downcut:
            resultados.append(0)
        elif lista[i] < upcut:
            resultados.append(1)
        else:
            resultados.append(2)
        i+=1

    return resultados

def percentage_OK(sum_classified, lenseq, uniprotid, type):
    df = pd.read_csv(type+'_prediction'+uniprotid+'.csv', "\t")
    if type=="5" or type=="3":
        real_flex=df['pred_'+type].tolist()
    else:
        real_flex=df[type].tolist()
    calidad=0
    for a,b in zip(sum_classified,real_flex):
        if int(a) == int(b):
            calidad += 1
    return calidad/lenseq
