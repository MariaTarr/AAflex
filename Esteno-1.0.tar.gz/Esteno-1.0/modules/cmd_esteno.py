import sys
from modules.createDict import *
from modules.modifyData import *
from modules.downloadFiles import *
from modules.classes import *
from modules.BioPythonFunctions import *
import matplotlib.pyplot as plt
import numpy as np
from tkinter import *
from PIL import ImageTk, Image
import os
from tkinter import messagebox
from modules.tkfunctions import *
from modules.maxminfunctions import *
from modules.checkresults import *
from modules.graphics import *
import pandas as pd
from tkinter import *
from PIL import ImageTk, Image
from modules.main_esteno import main
# # Parsing the sequence and saving its length in a variable

def cmd_run():
	""" Reas fasta file from command line and return sequence as string """
	prot=get_fasta(sys.argv[1])
	sq=prot[1]
	main(sq)

if __name__== "__main__":
	cmd_run()
