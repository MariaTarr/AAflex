def max_sides(list1, i):
    #list3=list(range(0,len(list1)))

    countleft=0
    a=i-1
    laresta=list1[i]-list1[a]
    while laresta>0:
        countleft+=1
        laresta=list1[a]-list1[a-1]
        a=a-1

    countright=0
    b=i+1
    laresta=list1[i]-list1[b]
    while laresta>0:
        countright+=1
        laresta=list1[b]-list1[b+1]
        b=b+1

    power=min(countleft, countright)

    return power

def min_sides(list1, i):
    #list3=list(range(0,len(list1)))

    countleft=0
    a=i-1
    laresta=list1[a]-list1[i]
    while laresta>0:
        countleft+=1
        laresta=list1[a-1]-list1[a]
        a=a-1

    countright=0
    b=i+1
    laresta=list1[b]-list1[i]
    while laresta>0:
        countright+=1
        laresta=list1[b+1]-list1[b]
        b=b+1

    power=min(countleft, countright)*(-1)

    return power

def max_min2(list1, lenseq):
    i=0
    list2=list(range(0,len(list1)))
    while i< lenseq:
        if i>5 and i<(lenseq-6):
            mini_list=list1[(i-5):(i+5)]
            max1=max(mini_list)
            min1=min(mini_list)
            if list1[i]==max1:
                max2=max_sides(list1, i)
                lower=min(list1[i-max2],list1[i+max2])
                distance=list1[i]-lower
                list2[i]=max2
                a=i-1
                b=i+1
                max3=max2-1
                while max3>0:
                    list2[a]=max2*(distance-(list1[i]-list1[a]))/distance
                    list2[b]=max2*(distance-(list1[i]-list1[b]))/distance
                    a=a-1
                    b=b+1
                    max3=max3-1
            elif list1[i]==min1:
                min2=min_sides(list1, i)
                upper=max(list1[i-min2],list1[i+min2])
                distance=upper-list1[i]
                list2[i]=min2
                a=i-1
                b=i+1
                min3=min2+1
                while min3<0:
                    list2[a]=min2*(distance-(list1[a]-list1[i]))/distance
                    list2[b]=min2*(distance-(list1[b]-list1[i]))/distance
                    a=a-1
                    b=b+1
                    min3=min3+1
            else:
                if abs(list2[i]) > abs(list2[i-1]):
                    list2[i]=0
        else:
            if abs(list2[i]) > abs(list2[i-1]):
                list2[i]=0
        i+=1
    return list2


def max_min_rm(list1, lenseq):
    """Given a list returned by max_min2() it returns the same list but without the picks of 1"""
    list2=max_min2(list1, lenseq)
    i=0
    list3=list(range(0,len(list1)))

    while i< lenseq:
        if i>5 and i<(lenseq-6):
            if abs(list2[i])==1:
                list3[i]=0
                list3[i-1]=0
                list3[i+1]=0
            else:
                if abs(list2[i-1]) != 1:
                    list3[i]=list2[i]
        else:
            list3[i]=0
        i+=1
    return list3
