import numpy as np

def smoothing(list, winsize, lenseq):
    smoothed_list=[]
    i=0
    while i<winsize:
        smoothed_list.append(sum(list[:i+1])/(i+1))
        i+=1
    while i< lenseq-winsize:
        smoothed_list.append(sum(list[i-int(winsize/2):i+int(winsize/2)])/winsize)
        i+=1
    while i<lenseq:
        smoothed_list.append(sum(list[i:])/(lenseq-i))
        i+=1

    return smoothed_list

def standarize_list(list):
    mu = np.average(list)
    sigma = np.std(list)
    z = (list-mu)/sigma
    return z

def move_to_0_2(list, lenseq):
    """2 will be the mean of the higher 10%, 0 will be the mean of the lower 10%"""

    sorted_list=sorted(list)

    new0=np.average(sorted_list[3:int(lenseq*0.1)+3])   #+3 to avoid ouliers
    new2=np.average(sorted_list[int(lenseq*0.9)-3:-4])
    range02=new2-new0
    newlist=[]
    i=0
    while i<lenseq:
        if list[i]>new2:
            newlist.append(2)

        elif list[i]<new0:
            newlist.append(0)

        else:
            newvalue=2*(list[i]-new0)/range02
            newlist.append(newvalue)
        i+=1

    return newlist

def flexible_env(list, lenseq):
    """Given a list with 0 if the aa has an average flexibility<0.5 and 1 if  the aa has an average flexibility>0.5(R. BHASKARAN,P.K. PONNUSWAMY, 1988), returns a list with 1 if there are 3 or more flexible aas surrounding each concrete aa (aa and its neighbours are 5 in total)"""
    newlist=[]
    i=0
    while i<lenseq:
        if i>1 and i<lenseq-2:
            mini_list=list[(i-2):(i+3)]
            sumof1=sum(mini_list)
            if sumof1>2:
                newlist.append(1)
            else:
                newlist.append(0)

        else:
            newlist.append(0.5)
        i+=1
    return newlist
# def max_min(list,lenseq):
#     """Returns 1 if it is a max, 2 if it is a super max,
#     -1 if it is a min, -2 a super min and 0 if it is none of them"""
#     max_min_list=[]
#     i=0
#     while i<4:
#         max_min_list.append(0)
#         i+=1
#     while i>=4 and i<=lenseq-5:
#         left=[]
#         left.append(list[i-3]-list[i-4])
#         left.append(list[i-2]-list[i-3])
#         left.append(list[i-1]-list[i-2])
#         left.append(list[i]-list[i-1])
#         right=[]
#         right.append(list[i+1]-list[i])
#         right.append(list[i+2]-list[i+1])
#         right.append(list[i+3]-list[i+2])
#         right.append(list[i+4]-list[i+3])
#         if left[2]*right[0]>0 or left[2]*left[1]<0 or right[2]*right[1]<0:
#             max_min_list.append(0)
#         else:
#             if left[0] and left[1] and left[2] and left[3] > 0 and right[0] and right[1] and right[2] and right[3] < 0:
#                 max_min_list.append(3)
#             elif left[0] and left[1] and left[2] and left[3] < 0 and right[0] and right[1] and right[2] and right[3] > 0:
#                 max_min_list.append(-3)
#             elif left[2]*left[1]>0 and right[2]*right[1]>0 and left[2]*left[0]>0 and left[2]*left[0]>0 and left[1]*left[0]>0 and left[1]*left[0]>0:
#                 if list[i]>list[i-1]:
#                     max_min_list.append(2)
#                 else:
#                     max_min_list.append(-2)
#
#             else:
#                 if list[i]>list[i-1]:
#                     max_min_list.append(1)
#                 else:
#                     max_min_list.append(-1)
#         i+=1
#     while i<lenseq:
#         max_min_list.append(0)
#         i+=1
#     return max_min_list
