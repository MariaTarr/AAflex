class UnavailableStructure(Exception):
	'''class to handle sequences that not correspond to the specified class'''
	def __init__(self, idf, evalue):
		self.idf = idf
		self.evalue = evalue
	
	def __str__(self):
		return "There is no available structure for the given sequence"
